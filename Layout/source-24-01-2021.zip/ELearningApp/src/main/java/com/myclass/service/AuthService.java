package com.myclass.service;

import com.myclass.dto.LoginDto;

public interface AuthService {

	String login(LoginDto dto);
}
